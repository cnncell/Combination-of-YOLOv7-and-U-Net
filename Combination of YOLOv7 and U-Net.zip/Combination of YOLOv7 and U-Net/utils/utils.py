import random
import numpy as np
import torch
from PIL import Image
import cv2


#---------------------------------------------------------#
#   Convert the image to an RGB image to prevent errors in grayscale image prediction.
#   The code only supports prediction on RGB images; all other types of images will be converted to RGB.
#---------------------------------------------------------#
def cvtColor(image):
    if len(np.shape(image)) == 3 and np.shape(image)[2] == 3:
        return image 
    else:
        image = image.convert('RGB')
        return image 

#---------------------------------------------------#
#   Resize the input image
#---------------------------------------------------#
def resize_image(image, size, letterbox_image, mode='PIL'):
    if mode == 'PIL':
        iw, ih  = image.size
        w, h    = size

        if letterbox_image:
            scale   = min(w / iw, h / ih)
            nw      = int(iw * scale)
            nh      = int(ih * scale)

            image   = image.resize((nw, nh), Image.BICUBIC)
            new_image = Image.new('RGB', size, (128, 128, 128))
            new_image.paste(image, ((w - nw) // 2, (h - nh) // 2))
        else:
            new_image = image.resize((w, h), Image.BICUBIC)
    else:
        image = np.array(image)
        if letterbox_image:
            # Get the current shape
            shape       = np.shape(image)[:2]
            # Get the output shape
            if isinstance(size, int):
                size    = (size, size)

            # Calculate the scaling ratio
            r = min(size[0] / shape[0], size[1] / shape[1])

            # Calculate the height and width of the scaled image
            new_unpad   = int(round(shape[1] * r)), int(round(shape[0] * r))
            dw, dh      = size[1] - new_unpad[0], size[0] - new_unpad[1]

            # Divide by 2 to pad both sides
            dw          /= 2  
            dh          /= 2
    
            # Resize the image
            if shape[::-1] != new_unpad:  # resize
                image = cv2.resize(image, new_unpad, interpolation=cv2.INTER_LINEAR)
            top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
            left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    
            new_image = cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(128, 128, 128))  # add border
        else:
            new_image = cv2.resize(image, (w, h))

    return new_image

#---------------------------------------------------#
#   Get classes
#---------------------------------------------------#
def get_classes(classes_path):
    with open(classes_path, encoding='utf-8') as f:
        class_names = f.readlines()
    class_names = [c.strip() for c in class_names]
    return class_names, len(class_names)

#---------------------------------------------------#
#   Get anchors
#---------------------------------------------------#
def get_anchors(anchors_path):
    '''loads the anchors from a file'''
    with open(anchors_path, encoding='utf-8') as f:
        anchors = f.readline()
    anchors = [float(x) for x in anchors.split(',')]
    anchors = np.array(anchors).reshape(-1, 2)
    return anchors, len(anchors)

#---------------------------------------------------#
#   Get learning rate
#---------------------------------------------------#
def get_lr(optimizer):
    for param_group in optimizer.param_groups:
        return param_group['lr']

#---------------------------------------------------#
#   Set seed
#---------------------------------------------------#
def seed_everything(seed=11):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

#---------------------------------------------------#
#   Set seed for Dataloader
#---------------------------------------------------#
def worker_init_fn(worker_id, rank, seed):
    worker_seed = rank + seed
    random.seed(worker_seed)
    np.random.seed(worker_seed)
    torch.manual_seed(worker_seed)

def preprocess_input(image):
    image /= 255.0
    return image

def show_config(**kwargs):
    print('Configurations:')
    print('-' * 70)
    print('|%25s | %40s|' % ('keys', 'values'))
    print('-' * 70)
    for key, value in kwargs.items():
        print('|%25s | %40s|' % (str(key), str(value)))
    print('-' * 70)
        
def download_weights(phi, model_dir="./model_data"):
    import os
    from torch.hub import load_state_dict_from_url
    
    download_urls = {
        "l" : 'https://github.com/bubbliiiing/yolov7-pytorch/releases/download/v1.0/yolov7_backbone_weights.pth',
        "x" : 'https://github.com/bubbliiiing/yolov7-pytorch/releases/download/v1.0/yolov7_x_backbone_weights.pth',
    }
    url = download_urls[phi]
    
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)  
    load_state_dict_from_url(url, model_dir)