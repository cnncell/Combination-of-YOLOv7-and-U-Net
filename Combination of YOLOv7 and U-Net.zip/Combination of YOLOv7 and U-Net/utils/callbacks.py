import datetime
import os

import torch
import matplotlib
matplotlib.use('Agg')
import scipy.signal
from matplotlib import pyplot as plt
from torch.utils.tensorboard import SummaryWriter

import shutil
import numpy as np

from PIL import Image
from tqdm import tqdm
from .utils import cvtColor, preprocess_input, resize_image
from .utils_bbox import DecodeBox
from .utils_map import get_coco_map, get_map


class LossHistory():
    def __init__(self, log_dir, model, input_shape):
        self.log_dir    = log_dir  # Directory to save logs
        self.losses     = []       # List to store training losses
        self.val_loss   = []       # List to store validation losses
        
        os.makedirs(self.log_dir, exist_ok=True)
        self.writer     = SummaryWriter(self.log_dir)  # TensorBoard writer
        
        # Try to add model graph to TensorBoard
        try:
            dummy_input     = torch.randn(2, 3, input_shape[0], input_shape[1])
            self.writer.add_graph(model, dummy_input)
        except:
            pass

    def append_loss(self, epoch, loss, val_loss):
        """Record loss values for training and validation"""
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        self.losses.append(loss)
        self.val_loss.append(val_loss)

        # Save loss values to text files
        with open(os.path.join(self.log_dir, "epoch_loss.txt"), 'a') as f:
            f.write(str(loss))
            f.write("\n")
        with open(os.path.join(self.log_dir, "epoch_val_loss.txt"), 'a') as f:
            f.write(str(val_loss))
            f.write("\n")

        # Log to TensorBoard
        self.writer.add_scalar('loss', loss, epoch)
        self.writer.add_scalar('val_loss', val_loss, epoch)
        
        # Update loss plot
        self.loss_plot()

    def loss_plot(self):
        """Generate and save loss curve plot"""
        iters = range(len(self.losses))

        plt.figure()
        plt.plot(iters, self.losses, 'red', linewidth=2, label='train loss')
        plt.plot(iters, self.val_loss, 'coral', linewidth=2, label='val loss')
        
        # Add smoothed curves using Savitzky-Golay filter
        try:
            if len(self.losses) < 25:
                window_size = 5
            else:
                window_size = 15
            
            plt.plot(iters, scipy.signal.savgol_filter(self.losses, window_size, 3), 
                     'green', linestyle='--', linewidth=2, label='smooth train loss')
            plt.plot(iters, scipy.signal.savgol_filter(self.val_loss, window_size, 3), 
                     '#8B4513', linestyle='--', linewidth=2, label='smooth val loss')
        except:
            pass

        plt.grid(True)
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend(loc="upper right")

        # Save plot
        plt.savefig(os.path.join(self.log_dir, "epoch_loss.png"))

        # Clean up
        plt.cla()
        plt.close("all")


class EvalCallback():
    def __init__(self, net, input_shape, anchors, anchors_mask, class_names, num_classes, val_lines, log_dir, cuda, \
            map_out_path=".temp_map_out", max_boxes=100, confidence=0.05, nms_iou=0.5, letterbox_image=True, MINOVERLAP=0.5, eval_flag=True, period=1):
        super(EvalCallback, self).__init__()
        
        self.net                = net                  # Network model
        self.input_shape        = input_shape          # Input image size (height, width)
        self.anchors            = anchors              # Anchor box coordinates
        self.anchors_mask       = anchors_mask         # Mask for anchor box groups
        self.class_names        = class_names          # List of class names
        self.num_classes        = num_classes          # Number of classes
        self.val_lines          = val_lines            # Validation dataset annotations
        self.log_dir            = log_dir              # Directory to save logs
        self.cuda               = cuda                 # Whether to use GPU
        self.map_out_path       = map_out_path         # Temporary directory for mAP calculation
        self.max_boxes          = max_boxes            # Maximum number of detection boxes
        self.confidence         = confidence           # Confidence threshold for predictions
        self.nms_iou            = nms_iou              # IoU threshold for non-maximum suppression
        self.letterbox_image    = letterbox_image      # Whether to use letterbox resize
        self.MINOVERLAP         = MINOVERLAP           # Minimum overlap for mAP calculation
        self.eval_flag          = eval_flag            # Whether to enable evaluation
        self.period             = period               # Evaluation period (every N epochs)
        
        # Bounding box decoder
        self.bbox_util          = DecodeBox(self.anchors, self.num_classes, 
                                           (self.input_shape[0], self.input_shape[1]), self.anchors_mask)
        
        # Tracking metrics
        self.maps       = [0]          # mAP values for each evaluation
        self.epoches    = [0]          # Epochs corresponding to mAP values
        
        # Initialize log file if evaluation is enabled
        if self.eval_flag:
            with open(os.path.join(self.log_dir, "epoch_map.txt"), 'a') as f:
                f.write(str(0))
                f.write("\n")

    def get_map_txt(self, image_id, image, class_names, map_out_path):
        """Generate detection results in text format for mAP calculation"""
        # Create detection results file
        f = open(os.path.join(map_out_path, "detection-results/"+image_id+".txt"), "w", encoding='utf-8') 
        image_shape = np.array(np.shape(image)[0:2])  # (height, width)
        
        # Convert image to RGB format (required for consistent processing)
        image       = cvtColor(image)
        # Resize image with letterboxing (maintains aspect ratio)
        image_data  = resize_image(image, (self.input_shape[1], self.input_shape[0]), self.letterbox_image)
        # Preprocess image for model input
        image_data  = np.expand_dims(np.transpose(preprocess_input(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

        with torch.no_grad():  # Disable gradient calculation for inference
            images = torch.from_numpy(image_data)
            if self.cuda:
                images = images.cuda()  # Move to GPU if available
            
            # Get model predictions
            outputs = self.net(images)
            # Decode bounding boxes
            outputs = self.bbox_util.decode_box(outputs)
            # Apply non-maximum suppression
            results = self.bbox_util.non_max_suppression(torch.cat(outputs, 1), self.num_classes, self.input_shape, 
                        image_shape, self.letterbox_image, conf_thres=self.confidence, nms_thres=self.nms_iou)
                                                    
            if results[0] is None:  # No detections
                f.close()
                return 

            # Extract detection results
            top_label   = np.array(results[0][:, 6], dtype='int32')  # Class labels
            top_conf    = results[0][:, 4] * results[0][:, 5]         # Confidence scores
            top_boxes   = results[0][:, :4]                           # Bounding boxes (x1, y1, x2, y2)

        # Keep only top N detections
        top_100     = np.argsort(top_conf)[::-1][:self.max_boxes]
        top_boxes   = top_boxes[top_100]
        top_conf    = top_conf[top_100]
        top_label   = top_label[top_100]

        # Write results to file
        for i, c in list(enumerate(top_label)):
            predicted_class = self.class_names[int(c)]
            box             = top_boxes[i]
            score           = str(top_conf[i])

            top, left, bottom, right = box
            if predicted_class not in class_names:
                continue

            # Format: class_name score left top right bottom
            f.write(f"{predicted_class} {score[:6]} {int(left)} {int(top)} {int(right)} {int(bottom)}\n")

        f.close()
        return 
    
    def on_epoch_end(self, epoch, model_eval):
        """Perform evaluation at the end of an epoch"""
        # Only evaluate every 'period' epochs if enabled
        if epoch % self.period == 0 and self.eval_flag:
            self.net = model_eval  # Update network with current weights
            
            # Create temporary directories for mAP calculation
            if not os.path.exists(self.map_out_path):
                os.makedirs(self.map_out_path)
            if not os.path.exists(os.path.join(self.map_out_path, "ground-truth")):
                os.makedirs(os.path.join(self.map_out_path, "ground-truth"))
            if not os.path.exists(os.path.join(self.map_out_path, "detection-results")):
                os.makedirs(os.path.join(self.map_out_path, "detection-results"))
            
            print("Generating mAP data...")
            # Process each validation sample
            for annotation_line in tqdm(self.val_lines):
                line        = annotation_line.split()
                image_id    = os.path.basename(line[0]).split('.')[0]  # Get image ID
                
                # Load image
                image       = Image.open(line[0])
                # Parse ground truth boxes
                gt_boxes    = np.array([np.array(list(map(int, box.split(',')))) for box in line[1:]])
                
                # Generate detection results text file
                self.get_map_txt(image_id, image, self.class_names, self.map_out_path)
                
                # Generate ground truth text file
                with open(os.path.join(self.map_out_path, "ground-truth/"+image_id+".txt"), "w") as new_f:
                    for box in gt_boxes:
                        left, top, right, bottom, obj = box
                        obj_name = self.class_names[obj]
                        new_f.write(f"{obj_name} {left} {top} {right} {bottom}\n")
                        
            print("Calculating mAP...")
            # Calculate mAP using either COCO or VOC method
            try:
                # Try COCO mAP (0.50:0.95)
                temp_map = get_coco_map(class_names=self.class_names, path=self.map_out_path)[1]
            except:
                # Fallback to VOC mAP at specified overlap threshold
                temp_map = get_map(self.MINOVERLAP, False, path=self.map_out_path)
            
            # Update tracking lists
            self.maps.append(temp_map)
            self.epoches.append(epoch)

            # Save mAP to log file
            with open(os.path.join(self.log_dir, "epoch_map.txt"), 'a') as f:
                f.write(str(temp_map))
                f.write("\n")
            
            # Generate and save mAP curve plot
            plt.figure()
            plt.plot(self.epoches, self.maps, 'red', linewidth=2, label='mAP')

            plt.grid(True)
            plt.xlabel('Epoch')
            plt.ylabel(f'mAP@{self.MINOVERLAP}')
            plt.title('mAP Curve')
            plt.legend(loc="upper right")

            plt.savefig(os.path.join(self.log_dir, "epoch_map.png"))
            plt.cla()
            plt.close("all")

            print("mAP calculation completed.")
            # Clean up temporary files
            shutil.rmtree(self.map_out_path)